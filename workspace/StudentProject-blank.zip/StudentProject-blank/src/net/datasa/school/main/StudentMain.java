package net.datasa.school.main;

import net.datasa.school.ui.StudentUI;

public class StudentMain {

	public static void main(String[] args) {
		new StudentUI();
	}

}
