package net.datasa.school.vo;

public class Student {
	//멤버변수(필드)
	
	//사용자 정의 생성자
	
	//3과목의 평균 계산
	private void calcAvg() {
		
	}
	
	//엑세서(accessor) Getter, Setter

	//toString() 재정의
	
}


















