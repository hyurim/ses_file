module mod_main {
	requires mod_util;
}
