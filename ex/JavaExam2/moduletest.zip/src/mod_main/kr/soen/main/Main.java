package kr.soen.main;
import kr.soen.util.Util;

public class Main {
	public static void main(String[] args) {
		System.out.println(Util.add(12, 34));
	}
}
