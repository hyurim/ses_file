module mod_util {
		exports kr.soen.util;
}
